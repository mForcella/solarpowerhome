<?php 
	add_action( 'wp_enqueue_scripts', 'solar_power_theme_enqueue_styles' );
	function solar_power_theme_enqueue_styles() {
		wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' ); 
	} 
?>